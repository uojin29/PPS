package second;

import java.util.Scanner;

public class A111_JangYujin_20230725 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int tc = scanner.nextInt();
        for (int i = 0; i < tc; i++) {
            int x = scanner.nextInt();
            double res = Math.pow(2.0, x) - 1;
            System.out.println((int) res);
        }

        scanner.close();
    }
}

A083, A084, A085, A094, A104, A105, A106, A107, A108, A109, A110, A111,